const decrement = () => {
  return {
    type: "decrement"
  };
};

export default decrement;
