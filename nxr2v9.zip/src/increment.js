const increment = () => {
  return {
    type: "increment"
  };
};

export default increment;
