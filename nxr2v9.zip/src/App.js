import "./styles.css";
import "./heading.css";
import "./bg.css";
import "./bg1.css";
import "./text.css";
import store from "./store.js";
import { Provider } from "react-redux";

import Cart from "./body.js";
export default function App() {
  return (
    <div>
      <div className="bg1">
        <Provider store={store}>
          <Cart />
        </Provider>
      </div>
    </div>
  );
}
