import "./bg2.css";
import "./img.css";
import "./button.css";
import "./style.css";
import "./m.css";
import { Component } from "react";
import "./bg.css";
import "./b.css";
import "./button1.css";
import "./button3.css";
import "./img1.css";
import { increment } from "./increment.js";
import { connect } from "react-redux";
let a = 0;
class Display extends Component {
  state = { count1: 0, load: true, bs: "img" };

  decrement = (id) => {
    const { delete1 } = this.props;

    this.setState((prevState) => ({ count1: prevState.count1 - 1 }));

    const { count1 } = this.state;
    delete1(id, count1 - 2);
  };

  add = (id) => {
    const { delete1 } = this.props;
    this.setState((prevState) => ({ count1: prevState.count1 + 1 }));
    const { count1 } = this.state;

    delete1(id, count1);
    console.log("mmm");
  };

  add1 = (id) => {
    const { delete2 } = this.props;
    this.setState({
      load: false
    });

    delete2(id);

    setTimeout(() => {
      this.setState({
        load: true
      });
    }, 4000);
  };

  add2 = (id) => {
    const { total } = this.props;
    total(id);
  };
  zoom = () => {
    this.setState({
      bs: "img1"
    });
  };

  zoom1 = () => {
    this.setState({
      bs: "img"
    });
  };
  render() {
    const { data } = this.props;

    const { count1, name1, load, bs } = this.state;

    let but;
    let but1;
    let but2;
    const { id, name, price, quantity, image } = data;

    but1 = (
      <div className="">
        <div className="fl">
          <button className="b" onClick={this.decrement} id={id}>
            -
          </button>
          <span className="p">{count1}</span>
          <button className="b" onClick={this.add} id={id}>
            +
          </button>
        </div>
      </div>
    );

    if (load) {
      but = (
        <button onClick={this.add1} className="button1" id={id}>
          Add to Cart
        </button>
      );
    } else {
      but = (
        <button onClick={this.add2} className="button3" id={id}>
          Go to Cart
        </button>
      );
    }
    return (
      <div>
        <li className="bg2">
          <div className="style">
            <div className="m">
              <h3>{name}</h3>
              <h3>{price}</h3>
              <h4>count:{quantity}</h4>
            </div>

            <div className="">
              <img
                src={image}
                className={bs}
                alt=""
                onMouseOver={this.zoom}
                onMouseOut={this.zoom1}
              />
            </div>
          </div>
          <div className="button">
            <div>{but1}</div>
            <div>{but}</div>
          </div>
        </li>
      </div>
    );
  }
}

const map = (dispatch) => {
  return {
    increment: () => dispatch(increment())
  };
};

export default connect(map)(Display);
