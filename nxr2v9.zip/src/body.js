import { Component } from "react";
import Display from "./Display.js";
import "./wrap.css";
import { BsCart4 } from "react-icons/bs";
import "./p.css";
import "./w.css";
import "./icon.css";
import "./c.css";
import "./fl.css";
import Order from "./Order.js";
import "./f.css";
import "../n.css";
let products = [
  {
    id: 0,
    name: "Dettol soap",
    price: "40 Rs",
    quantity: 10,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733700/det_y9rnli.png"
  },
  {
    id: 1,
    name: "Head Shoulder",
    price: "60 Rs",
    quantity: 8,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733505/shoul_y7t8r6.png"
  },
  {
    id: 2,
    name: "Lux Soap",
    price: "38 Rs",
    quantity: 20,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733329/luxa_grj2cq.png"
  },
  {
    id: 3,
    name: "Medimix Soap",
    price: "36 Rs",
    quantity: 12,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733186/med_myxezt.png"
  },
  {
    id: 4,
    name: "Dove Soap",
    price: "42 Rs",
    quantity: 20,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707747/dove.jp_olhahn.jpg"
  },
  {
    id: 5,
    name: "Santoor Soap",
    price: "30 Rs",
    quantity: 15,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707422/santoor_dhptus.jpg"
  },
  {
    id: 6,
    name: "Pears",
    price: "50 Rs",
    quantity: 30,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707499/pears_lalfdv.webp"
  },
  {
    id: 7,
    name: "Close up",
    price: "20 Rs",
    quantity: 13,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707870/closeup_jj8fs3.jpg"
  },
  {
    id: 8,
    name: "Cinthol soap",
    price: "40 Rs",
    quantity: 9,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707987/cinthol_iczk8o.jpg"
  },
  {
    id: 9,
    name: "Rexona soap",
    price: "34 Rs",
    quantity: 25,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667732943/rex_lnkrw8.png"
  },
  {
    id: 10,
    name: "Life Buoy",
    price: "40 Rs",
    quantity: 11,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733421/life_vwbd9b.png"
  },
  {
    id: 11,
    name: "Dove",
    price: "60 Rs",
    quantity: 14,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707787/dove_sampo_iahx17.jpg"
  }
];
let l = [];
let l1 = [];
let c3 = 0;
let x = true;
class Cart extends Component {
  state = {
    searchInput: "",
    details: products,
    count: 0,
    load: x,
    b: []
  };
  search = (e) => {
    this.setState({ searchInput: e.target.value });
  };
  delete2 = (number1) => {
    if (l1.includes(String(number1.target.id))) {
    } else {
      c3 = c3 + 1;
      this.setState({ count: c3 });

      l1.push(number1.target.id);
      console.log(c3);
    }
  };
  delete1 = (number1, number2) => {
    const { b } = this.state;
    const c = {
      id2: number1.target.id,
      count2: number2 + 1
    };

    console.log(l.values());

    if (b.length > 0) {
      if (l.includes(String(number1.target.id))) {
        for (let i = 0; i < b.length; i++) {
          if (b[i].id2 === number1.target.id) {
            b[i].count2 = c.count2;
          }
        }
      } else {
        l.push(number1.target.id);
        this.setState((prevState) => ({
          b: [...prevState.b, c]
        }));
      }
    } else {
      l.push(number1.target.id);

      this.setState((prevState) => ({
        b: [...prevState.b, c]
      }));
    }
  };
  ram = () => {
    this.setState({ load: false });
  };

  total = (x) => {
    this.setState({ load: !x });
  };

  render() {
    const { details, searchInput, b, count, load } = this.state;

    const filter = details.filter((each) =>
      each.name.toLowerCase().includes(searchInput.toLowerCase())
    );

    let a1;
    let by;
    if (count === 0) {
      by = <sup className="c">{}</sup>;
    } else {
      by = <sup className="c">{count}</sup>;
    }

    let d;
    if (load) {
      d = (
        <div>
          <div className="w">
            <h1 className="heading">Shopping cart</h1>
            <div className="fl">
              <input
                type="text"
                className="text"
                onChange={this.search}
                placeholder="search product here...."
              />
              <BsCart4 className="icon" onClick={this.total} />
              {by}
            </div>
          </div>
          <div>{a1}</div>

          <ul className="wrap">
            {filter.map((each) => (
              <Display
                data={each}
                delete1={this.delete1}
                add={this.add}
                delete2={this.delete2}
                total={this.total}
              />
            ))}
          </ul>
        </div>
      );
    } else {
      d = <Order b={b} c3={c3} total={this.total} />;
    }
    return <div>{d}</div>;
  }
}

export default Cart;
