import "./back.css";
import "./back1.css";
import "./h.css";
import "./style3.css";
import "./display.css";
import "./f3.css";
import "./hr.css";
import "./hr1.css";
import "./h4.css";
import { useState } from "react";
import "./head.css";
let products = [
  {
    id: 0,
    name: "Dettol soap",
    price: 40,
    quantity: 10,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733700/det_y9rnli.png"
  },
  {
    id: 1,
    name: "Head Shoulder",
    price: 60,
    quantity: 8,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733505/shoul_y7t8r6.png"
  },
  {
    id: 2,
    name: "Lux Soap",
    price: 38,
    quantity: 20,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733329/luxa_grj2cq.png"
  },
  {
    id: 3,
    name: "Medimix Soap",
    price: 36,
    quantity: 12,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733186/med_myxezt.png"
  },
  {
    id: 4,
    name: "Dove Soap",
    price: 42,
    quantity: 20,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707747/dove.jp_olhahn.jpg"
  },
  {
    id: 5,
    name: "Santoor Soap",
    price: 30,
    quantity: 15,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707422/santoor_dhptus.jpg"
  },
  {
    id: 6,
    name: "Pears",
    price: 50,
    quantity: 30,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707499/pears_lalfdv.webp"
  },
  {
    id: 7,
    name: "Close up",
    price: 20,
    quantity: 13,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707870/closeup_jj8fs3.jpg"
  },
  {
    id: 8,
    name: "Cinthol soap",
    price: 40,
    quantity: 9,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707987/cinthol_iczk8o.jpg"
  },
  {
    id: 9,
    name: "Rexona soap",
    price: 34,
    quantity: 25,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667732943/rex_lnkrw8.png"
  },
  {
    id: 10,
    name: "Life Buoy",
    price: 40,
    quantity: 11,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667733421/life_vwbd9b.png"
  },
  {
    id: 11,
    name: "Dove",
    price: 60,
    quantity: 14,
    image:
      "https://res.cloudinary.com/dbfg6emie/image/upload/v1667707787/dove_sampo_iahx17.jpg"
  }
];

const Order = (props) => {
  const [use, set] = useState(true);
  const { b, c3, total } = props;
  let c = 0;
  const del = () => {
    set(total(use));
  };

  b.map((e) => (c = c + products[e.id2].price * e.count2));

  return (
    <div>
      <div>
        <h1 onClick={del} classname="head">
          Shopping cart
        </h1>
      </div>
      <div className="back">
        <h1 className="h4">Your Cart Summary</h1>
        <div className="display">
          <div className="style">
            <p className="style3">Item(s) in cart</p>
            <p className="style3">Grand Total(INR)</p>
          </div>
          <div className="style">
            <h3 className="f3">{c3}</h3>
            <h3 className="f3"> {c}</h3>
          </div>
        </div>
        <hr className="hr" />
        <div className="back1">
          <h4 className="h">Product</h4>
          <h4 className="f">Quantity</h4>
          <h4 className="f">price</h4>
        </div>

        {b.map((each) => (
          <div>
            <div className="back1">
              <p className="h">{products[each.id2].name}</p>
              <p className="h4">{each.count2}</p>
              <p className="h4">{products[each.id2].price * each.count2}</p>
            </div>
            <hr className="hr1" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Order;
