import increment from "./increment.js";
import decrement from "./decrement.js";

const InitialState = {
  count3: 0
};

const reducer = (state = InitialState, action) => {
  switch (action.type) {
    case increment:
      return {
        ...state,
        count1: state.count3 + 1
      };

    case decrement:
      return {
        ...state,
        count1: state.count3 - 1
      };
    default:
      return state;
  }
};

export default reducer;
